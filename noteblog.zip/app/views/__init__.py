"""
视图层
"""
from . import main, auth, admin, api

__all__ = ['main', 'auth', 'admin', 'api']
