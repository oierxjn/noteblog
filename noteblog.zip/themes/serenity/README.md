# Serenity 主题

Serenity 是一款专为 Noteblog 打造的轻量化主题，灵感来自清晨的薄雾与干净的纸张。它延续 Aurora 主题的动效体验，同时通过更克制的配色、舒适的留白以及分明的排版层级带来专注的阅读氛围。

## ✨ 特性速览

- **玻璃态导航栏**：可在后台启用/禁用，滚动时自动收起
- **自适应英雄区**：支持自定义标题、文案与按钮
- **响应式卡片栅格**：根据布局密度自动调整卡片阴影与间距
- **可选暗黑模式**：记住用户偏好，平滑渐变
- **增强的侧边栏**：组件顺序可配置，默认提供最新文章 / 分类 / 标签
- **友好的评论区**：支持锚点跳转、快捷复制与轻量 Like 状态
- **插件钩子就绪**：在 head、sidebar、footer、post meta 等位置预留挂载点

## 📂 目录结构

```
serenity/
├── theme.json
├── README.md
├── screenshot.txt
├── extensions.py
├── static/
│   ├── css/serenity.css
│   └── js/serenity.js
└── templates/
    ├── base.html
    ├── index.html
    ├── post.html
    ├── search.html
    ├── archives.html
    ├── categories.html
    ├── category.html
    ├── tags.html
    ├── tag.html
    ├── 404.html
    ├── 500.html
    ├── pages/timeline.html
    ├── admin/base.html
    └── auth/login.html
```

## ⚙️ 配置项

`theme.json` 暴露了以下可调节选项：

| 键 | 说明 |
| --- | --- |
| `primary_color` | 页面主视觉色，默认晨雾蓝 `#4d6cfa` |
| `accent_color` | CTA 与按钮强调色 |
| `neutral_color` | 字体/图标基准色 |
| `hero_*` | 首页英雄区标题、副文案与按钮 |
| `layout_density` | 卡片密度（comfortable / cozy / compact）|
| `enable_dark_mode` | 是否展示主题切换按钮 |
| `enable_glass_header` | 是否启用玻璃态导航背景 |
| `show_sidebar` | 是否显示右侧栏 |
| `sidebar_widgets` | 侧边栏组件顺序 |
| `footer_text` | 页脚版权文案 |
| `analytics_code` | 任意统计/埋点片段 |

## 🚀 使用方式

1. 将 `serenity` 文件夹拷贝到 `themes/` 目录
2. 在 Noteblog 后台的 **主题管理** 中启用 Serenity
3. 根据喜好在自定义器中调整颜色、英雄区与布局
4. 需要截图时替换 `screenshot.png`

## 🧩 扩展接口

- `extensions.py` 暴露后台 Blueprint：`/admin/theme/serenity/status`
- `CUSTOM_PAGES` 示例提供了 `/serenity/timeline` 自定义页面
- 模板内提供了 `hook('head')`、`hook('sidebar')`、`hook('footer')`、`hook('post_meta')` 等挂载点

## 📝 许可

MIT License — 欢迎在遵守协议的前提下，自由二次创作或发布 PR 改进本主题。
